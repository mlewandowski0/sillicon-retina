#include <cuda_runtime.h>
#include <iostream>
#include <vector>
#include "enums.h"

#define CUDA_CHECK(call)                                                          \
    do                                                                            \
    {                                                                             \
        cudaError_t err = call;                                                   \
        if (err != cudaSuccess)                                                   \
        {                                                                         \
            std::cerr << "CUDA error in " << __FILE__ << ":" << __LINE__ << " - " \
                      << cudaGetErrorString(err) << std::endl;                    \
            exit(EXIT_FAILURE);                                                   \
        }                                                                         \
    } while (0)

__constant__ float BLUR_kernel_3x3[9] = {
    1.0f / 9.0f, 1.0f / 9.0f, 1.0f / 9.0f,
    1.0f / 9.0f, 1.0f / 9.0f, 1.0f / 9.0f,
    1.0f / 9.0f, 1.0f / 9.0f, 1.0f / 9.0f};

__device__ float apply_blur_avg(int kernel_size, int W, int H,
                                const float *input,
                                int center_idx, int curr_t_offset)
{
    // calculate the 2D coordaintes from linear index
    int y = center_idx / W;
    int x = center_idx % W;

    float output = 0.0f;
    float cnt = 0.0f;

    int ks = kernel_size / 2;
    if (kernel_size == 3)
    {
        for (int dy = -1; dy <= 1; ++dy)
        {
            for (int dx = -1; dx <= 1; ++dx)
            {
                int ny = y + dy;
                int nx = x + dx;

                // bounds check
                if (ny >= 0 && ny < H && nx >= 0 && nx < W)
                {
                    int neighbor_idx = ny * W + nx;
                    output += input[curr_t_offset + neighbor_idx];
                    cnt += 1.0f;
                }
            }
        }
    }
    else
    {
        for (int dy = -ks; dy <= ks; ++dy)
        {
            for (int dx = -ks; dx <= ks; ++dx)
            {
                int ny = y + dy;
                int nx = x + dx;

                if (ny >= 0 && ny < H && nx >= 0 && nx < W)
                {
                    int neighbor_idx = ny * W + nx;
                    output += input[curr_t_offset + neighbor_idx];
                    cnt += 1.0f;
                }
            }
        }
    }

    return (cnt > 0.0f) ? output / cnt : 0.0f;
}

__device__ float apply_blur(BLUR_MODE mode,
                            int kernel_size, int W, int H,
                            const float *input,
                            int center_idx, int curr_t_offset)
{
    if (mode == BLUR_MODE::BLUR_AVG)
    {
        return apply_blur_avg(kernel_size, W, H, input, center_idx, curr_t_offset);
    }
    // TODO

    return apply_blur_avg(kernel_size, W, H, input, center_idx, curr_t_offset);
}

__forceinline__ __device__ float apply_low_pass_filter1(float incoming_value, float previous_value, float alpha)
{ // fmaf(x, y, z) -> z + x * y
    return fmaf(alpha, incoming_value - previous_value, previous_value);
}

__device__ float apply_low_pass_filter(LPF_MODE mode,
                                       float incoming_value,
                                       float previous_value,
                                       float alpha)
{
    if (mode == LPF_MODE::LPF_1)
    {
        return apply_low_pass_filter1(incoming_value, previous_value, alpha);
    }

    return apply_low_pass_filter1(incoming_value, previous_value, alpha);
}

__forceinline__ __device__ float apply_high_pass_filter1(float incoming_value, float previous_value)
{
    return incoming_value - previous_value;
}

__device__ float apply_high_pass_filter(HPF_MODE mode,
                                        float incoming_value,
                                        float previous_value)
{
    if (mode == HPF_MODE::HPF_1)
    {
        return apply_high_pass_filter1(incoming_value, previous_value);
    }

    return apply_high_pass_filter1(incoming_value, previous_value);
}

__forceinline__ __device__ float euler_method(float previous_value,
                                              float p1,
                                              float I_OPL,
                                              float g_A)
{
    // fmaf(x, y, z) -> z + x * y
    return fmaf(p1, fmaf(-g_A, previous_value, I_OPL), previous_value);
    // return previous_value + p1 * (I_OPL - g_A * previous_value);
}

__forceinline__ __device__ float apply_N(float incoming, float bias)
{
    return fmaxf(incoming, 0.0f) + bias;
}

__forceinline__ __device__ float compute_next_LIF1(float previous_LIF,
                                                   float p2,
                                                   float p3,
                                                   float I_gang,
                                                   float U_rest)
{
    // fmaf(x,y, z) -> z + x * y
    return fmaf(-p3, fabsf(previous_LIF - U_rest), fmaf(p2, I_gang, previous_LIF));
    // return previous_LIF + p2 * I_gang - p3 * abs(previous_LIF - U_rest);
}

__device__ float compute_next_LIF(LIF_INTEGRATION_MODE mode,
                                  float previous_LIF,
                                  float p2,
                                  float p3,
                                  float I_gang,
                                  float U_rest)
{
    if (mode == LIF_INTEGRATION_MODE::LIF_INTEGRATION_1)
    {
        return compute_next_LIF1(previous_LIF, p2, p3, I_gang, U_rest);
    }

    return compute_next_LIF1(previous_LIF, p2, p3, I_gang, U_rest);
}

__forceinline__ __device__ char fire_and_reset(LIF_RESET_MODE mode,
                                               float &V_LIF,
                                               float U_th,
                                               float U_reset)
{
    if (mode == LIF_RESET_MODE::LIF_SUBTRACT_RESET)
    {
        if (V_LIF >= U_th)
        {
            V_LIF -= U_reset;
            return 1; // mark as fired
        }
        return 0; // mark as not fired
    }

    return 0;
}

/********************************************************************
 * kernel A
 *******************************************************************/
__global__ void k_stageA(const float *__restrict__ imgs,
                         float *__restrict__ LPF1,
                         float *__restrict__ HPF1,
                         float *__restrict__ LPF2,
                         int lin_t_offset, int prev_offset, int curr_offset,
                         int H, int W,
                         float alpha1, float alpha2)
{
    const int idx = blockIdx.x * blockDim.x + threadIdx.x;
    const int HW = H * W;
    if (idx >= HW)
        return;

    int lin_idx = lin_t_offset + idx;
    int prev = prev_offset + idx;
    int curr = curr_offset + idx;

    float lpf1 = apply_low_pass_filter(LPF_MODE::LPF_1,
                                       imgs[lin_idx],
                                       LPF1[prev],
                                       alpha1);
    LPF1[curr] = lpf1;

    float hpf1 = lpf1 - LPF1[prev];
    HPF1[curr] = hpf1;

    LPF2[curr] = apply_low_pass_filter(LPF_MODE::LPF_1,
                                       hpf1,
                                       LPF2[prev],
                                       alpha2);
}

/********************************************************************
 * kernel B – first spatial blur (LPF2 → BLURRED2) + Q & V_BIP_LPF
 *******************************************************************/
__global__ void k_stageB(const float *__restrict__ LPF2,
                         float *__restrict__ BLURRED2,
                         float *__restrict__ I_OPL,
                         float *__restrict__ Q,
                         float *__restrict__ V_BIP_LPF,
                         const float *__restrict__ V_BIP, // t‑1
                         int lin_t_offset, int prev_offset, int curr_offset,
                         int H, int W,
                         float lambda_OPL,
                         float G_A_zero, float lambda_A,
                         float V_BIP_LPF_alpha)
{
    const int idx = blockIdx.x * blockDim.x + threadIdx.x;
    const int HW = H * W;
    if (idx >= HW)
        return;

    int prev = prev_offset + idx;
    int curr = curr_offset + idx;

    /* -------- spatial blur of LPF2 ------- */
    BLURRED2[curr] = apply_blur(BLUR_MODE::BLUR_AVG, 3, W, H,
                                LPF2, idx, curr - idx); // curr‑t slice base

    I_OPL[curr] = lambda_OPL * (BLURRED2[curr] - LPF2[curr]);

    Q[curr] = G_A_zero + lambda_A * fabsf(V_BIP[prev]);
    Q[curr] = fmaxf(0.0f, fminf(Q[curr], 1.0f));

    V_BIP_LPF[curr] = apply_low_pass_filter(LPF_MODE::LPF_1,
                                            Q[curr],
                                            V_BIP_LPF[prev],
                                            V_BIP_LPF_alpha);
}

/********************************************************************
 * kernel C – second spatial blur (g_A) + remaining stages
 *******************************************************************/
__global__ void k_stageC(const float *__restrict__ V_BIP_LPF,
                         float *__restrict__ V_BIP,
                         float *__restrict__ HPF2,
                         float *__restrict__ I_Gang,
                         float *__restrict__ V_LIF,
                         unsigned char *__restrict__ fired,
                         const float *__restrict__ I_OPL,
                         int lin_t_offset, int prev_offset, int curr_offset,
                         int H, int W,
                         float p1, float I_bias,
                         float p2, float p3,
                         float U_rest, float U_th, float U_reset)
{
    const int idx = blockIdx.x * blockDim.x + threadIdx.x;
    const int HW = H * W;
    if (idx >= HW)
        return;

    int prev = prev_offset + idx;
    int curr = curr_offset + idx;
    int lin_idx = lin_t_offset + idx;

    /* ------ spatial blur of V_BIP_LPF (g_A) ------ */
    float g_A = apply_blur(BLUR_MODE::BLUR_AVG, 3, W, H,
                           V_BIP_LPF, idx, curr - idx);

    V_BIP[curr] = euler_method(V_BIP[prev], p1,
                               I_OPL[curr], g_A);

    HPF2[curr] = V_BIP[curr] - V_BIP[prev];

    I_Gang[curr] = fmaxf(HPF2[curr], 0.0f) + I_bias;

    V_LIF[curr] = compute_next_LIF(LIF_INTEGRATION_MODE::LIF_INTEGRATION_1,
                                   V_LIF[prev], p2, p3,
                                   I_Gang[curr], U_rest);

    fired[lin_idx] = fire_and_reset(LIF_RESET_MODE::LIF_SUBTRACT_RESET,
                                    V_LIF[curr], U_th, U_reset);
}

void run_silicon_retina_model(
    const float *d_imgs,
    float *d_LPF1,
    float *d_HPF1,
    float *d_BLURRED2,
    float *d_LPF2,
    float *d_I_OPL,
    float *d_V_BIP,
    float *d_Q_V_BIP,
    float *d_V_BIP_LPF,
    float *d_HPF2,
    float *d_I_Gang,
    float *d_V_LIF,
    unsigned char *d_fired,

    int T, int H, int W,
    float alpha1,
    float alpha2,
    float V_BIP_LPF_alpha,
    float lambda_OPL,
    float G_A_zero,
    float lambda_A,
    float p1,
    float I_bias,
    float p2,
    float p3,
    float U_rest,
    float U_th,
    float U_reset)
{
    const int HW = H * W;
    int device;
    CUDA_CHECK(cudaGetDevice(&device));
    cudaDeviceProp prop;
    CUDA_CHECK(cudaGetDeviceProperties(&prop, device));

    int block, minGrid;
    CUDA_CHECK(cudaOccupancyMaxPotentialBlockSize(&minGrid, &block, k_stageA));
    block = (block / 32) * 32;
    if (block == 0)
        block = 256;
    int grid = (HW + block - 1) / block;

    int prev_offset = 0;
    int curr_offset = HW;
    int lin_t_offset = HW;

    for (int t = 1; t < T; ++t)
    {

        prev_offset = (t - 1) * HW;
        curr_offset = t * HW;
        lin_t_offset = t * HW;

        /* ---------- kernel A ---------- */
        k_stageA<<<grid, block>>>(d_imgs,
                                  d_LPF1, d_HPF1, d_LPF2,
                                  lin_t_offset, prev_offset, curr_offset,
                                  H, W, alpha1, alpha2);

        /* ---------- kernel B ---------- */
        k_stageB<<<grid, block>>>(d_LPF2, d_BLURRED2, d_I_OPL,
                                  d_Q_V_BIP, d_V_BIP_LPF, d_V_BIP,
                                  lin_t_offset, prev_offset, curr_offset, H, W,
                                  lambda_OPL, G_A_zero, lambda_A,
                                  V_BIP_LPF_alpha);

        /* ---------- kernel C ---------- */
        k_stageC<<<grid, block>>>(d_V_BIP_LPF, d_V_BIP, d_HPF2,
                                  d_I_Gang, d_V_LIF, d_fired,
                                  d_I_OPL,
                                  lin_t_offset, prev_offset, curr_offset, H, W,
                                  p1, I_bias, p2, p3,
                                  U_rest, U_th, U_reset);
    }

    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
}

void run_silicon_retina_model_fired_only(
    const float *d_imgs,
    float *d_LPF1,
    float *d_HPF1,
    float *d_BLURRED2,
    float *d_LPF2,
    float *d_I_OPL,
    float *d_V_BIP,
    float *d_Q_V_BIP,
    float *d_V_BIP_LPF,
    float *d_HPF2,
    float *d_I_Gang,
    float *d_V_LIF,
    unsigned char *d_fired,

    int T, int H, int W,
    float alpha1,
    float alpha2,
    float V_BIP_LPF_alpha,
    float lambda_OPL,
    float G_A_zero,
    float lambda_A,
    float p1,
    float I_bias,
    float p2,
    float p3,
    float U_rest,
    float U_th,
    float U_reset)
{
    const int HW = H * W;
    int device;
    CUDA_CHECK(cudaGetDevice(&device));
    cudaDeviceProp prop;
    CUDA_CHECK(cudaGetDeviceProperties(&prop, device));

    int block, minGrid;
    CUDA_CHECK(cudaOccupancyMaxPotentialBlockSize(&minGrid, &block, k_stageA));
    block = (block / 32) * 32;
    if (block == 0)
        block = 256;
    int grid = (HW + block - 1) / block;

    int prev_offset = 0;
    int curr_offset = HW;
    int lin_t_offset = HW;

    for (int t = 1; t < T; ++t)
    {

        const int current_double_buffer_idx = t % 2;
        const int previous_double_buffer_idx = (t - 1) % 2;

        curr_offset = current_double_buffer_idx * HW;
        prev_offset = previous_double_buffer_idx * HW;
        lin_t_offset = t * HW;

        /* ---------- kernel A ---------- */
        k_stageA<<<grid, block>>>(d_imgs,
                                  d_LPF1, d_HPF1, d_LPF2,
                                  lin_t_offset, prev_offset, curr_offset,
                                  H, W, alpha1, alpha2);

        /* ---------- kernel B ---------- */
        k_stageB<<<grid, block>>>(d_LPF2, d_BLURRED2, d_I_OPL,
                                  d_Q_V_BIP, d_V_BIP_LPF, d_V_BIP,
                                  lin_t_offset, prev_offset, curr_offset, H, W,
                                  lambda_OPL, G_A_zero, lambda_A,
                                  V_BIP_LPF_alpha);

        /* ---------- kernel C ---------- */
        k_stageC<<<grid, block>>>(d_V_BIP_LPF, d_V_BIP, d_HPF2,
                                  d_I_Gang, d_V_LIF, d_fired,
                                  d_I_OPL,
                                  lin_t_offset, prev_offset, curr_offset, H, W,
                                  p1, I_bias, p2, p3,
                                  U_rest, U_th, U_reset);
    }

    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
}

void run_silicon_retina_model_online(
    const float *d_imgs,
    float *d_LPF1,
    float *d_HPF1,
    float *d_BLURRED2,
    float *d_LPF2,
    float *d_I_OPL,
    float *d_V_BIP,
    float *d_Q_V_BIP,
    float *d_V_BIP_LPF,
    float *d_HPF2,
    float *d_I_Gang,
    float *d_V_LIF,
    unsigned char *d_fired,

    int curr_t, int H, int W,
    float alpha1,
    float alpha2,
    float V_BIP_LPF_alpha,
    float lambda_OPL,
    float G_A_zero,
    float lambda_A,
    float p1,
    float I_bias,
    float p2,
    float p3,
    float U_rest,
    float U_th,
    float U_reset)
{
    const int HW = H * W;
    int device;
    CUDA_CHECK(cudaGetDevice(&device));
    cudaDeviceProp prop;
    CUDA_CHECK(cudaGetDeviceProperties(&prop, device));

    int block, minGrid;
    CUDA_CHECK(cudaOccupancyMaxPotentialBlockSize(&minGrid, &block, k_stageA));
    block = (block / 32) * 32;
    if (block == 0)
        block = 256;
    int grid = (HW + block - 1) / block;

    int prev_offset = 0;
    int curr_offset = HW;
    int lin_t_offset = HW;

    const int current_double_buffer_idx = curr_t % 2;
    const int previous_double_buffer_idx = (curr_t - 1) % 2;

    curr_offset = current_double_buffer_idx * HW;
    prev_offset = previous_double_buffer_idx * HW;
    lin_t_offset = 0;

    /* ---------- kernel A ---------- */
    k_stageA<<<grid, block>>>(d_imgs,
                                  d_LPF1, d_HPF1, d_LPF2,
                                  lin_t_offset, prev_offset, curr_offset,
                                  H, W, alpha1, alpha2);

    /* ---------- kernel B ---------- */
    k_stageB<<<grid, block>>>(d_LPF2, d_BLURRED2, d_I_OPL,
                                  d_Q_V_BIP, d_V_BIP_LPF, d_V_BIP,
                                  lin_t_offset, prev_offset, curr_offset, H, W,
                                  lambda_OPL, G_A_zero, lambda_A,
                                  V_BIP_LPF_alpha);

    /* ---------- kernel C ---------- */
    k_stageC<<<grid, block>>>(d_V_BIP_LPF, d_V_BIP, d_HPF2,
                                  d_I_Gang, d_V_LIF, d_fired,
                                  d_I_OPL,
                                  lin_t_offset, prev_offset, curr_offset, H, W,
                                  p1, I_bias, p2, p3,
                                  U_rest, U_th, U_reset);
                        
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());
}